jQuery(document).ready(function ($) {

  var sticky = $("#myHeader");

  function getScrollLimit() {
    return ($(window).width() > 1199) ? 250 : 10;
  }

  function updateSpacing() {
    if (sticky.hasClass("sticky")) {
      var headerHeight = sticky.outerHeight() || 0;
      $('body').css('padding-top', headerHeight + 'px');
    }
  }

  function handleSticky() {
    var scroll = $(window).scrollTop();

    if (scroll >= getScrollLimit()) {
      if (!sticky.hasClass("sticky")) {
        sticky.addClass("sticky");
        updateSpacing();
      }
    } else {
      if (sticky.hasClass("sticky")) {
        sticky.removeClass("sticky");
        $('body').css('padding-top', '0px');
      }
    }
  }

  $(window).on('scroll', handleSticky);

  $(window).on('resize orientationchange', function () {
    updateSpacing();
  });

});

jQuery(document).ready(function () {
  jQuery("button.navbar-toggle").on("click", function () {
    jQuery("body").toggleClass("open-menu");
  });
});


jQuery(document).ready(function () {
  if (jQuery(window).width() > 1199) {
    jQuery("li.mega-menu ul.sub-menu").wrap(
      "<div class='hover_mega_menu'></div>"
    );
    jQuery("li.mega-menu2 ul.sub-menu").wrap(
      "<div class='hover_mega_menu'></div>"
    );
  }
});


jQuery(window).scroll(function () {
  var sticky = jQuery(".service-detail-right"),
    scroll = jQuery(window).scrollTop();
  if (scroll >= 50) {
    sticky.addClass("sticky")

  } else {
    sticky.removeClass("sticky")

  }
});



jQuery(function ($) {

  if (window.innerWidth < 1200) return;

  const menu = document.querySelector(".menu-top-menu-container");
  if (!menu) return;

  const links = menu.querySelectorAll(":scope > ul > li > a");
  if (!links.length) return;

  function moveLine(el) {
    const rect = el.getBoundingClientRect();
    const menuRect = menu.getBoundingClientRect();

    menu.style.setProperty("--menu-line-width", rect.width + "px");
    menu.style.setProperty(
      "--menu-line-left",
      rect.left - menuRect.left + "px"
    );
  }

  function resetLine() {
    menu.style.setProperty("--menu-line-width", "0px");
  }

  links.forEach(link => {
    link.addEventListener("mouseenter", () => moveLine(link));
  });

  menu.addEventListener("mouseleave", resetLine);

});



jQuery(document).ready(function ($) {
  var $scrollBtn = $('.scroll-top'),
    $path = $scrollBtn.find('path'),
    pathLength = $path[0].getTotalLength();

  // Set initial stroke
  $path.css({
    'stroke-dasharray': pathLength,
    'stroke-dashoffset': pathLength
  });

  // Update progress on scroll
  function updateProgress() {
    var scroll = $(window).scrollTop(),
      docHeight = $(document).height() - $(window).height(),
      progress = pathLength - (scroll * pathLength / docHeight);
    $path.css('stroke-dashoffset', progress);

    // Show/Hide button
    if (scroll > 50) {
      $scrollBtn.addClass('show');
    } else {
      $scrollBtn.removeClass('show');
    }
  }

  $(window).on('scroll', updateProgress);
  updateProgress();

  // Click to scroll top
  $scrollBtn.on('click', function () {
    $('html, body').animate({ scrollTop: 0 }, 700);
  });
});



jQuery(function ($) {

  jQuery(".logo-slider").owlCarousel({
    center: false,
    items: 9,
    loop: true,
    margin: 30,
    nav: false,
    dots: false,
    autoplay: true,
    slideTransition: 'linear',
    autoplayTimeout: 2000,
    autoplaySpeed: 2000,
    autoplayHoverPause: true,
    responsive: {
      0: {
        items: 3,
        margin: 10,
      },
      420: {
        items: 3,
        margin: 10,
      },
      575: {
        items: 4,
        margin: 10,
      },
      767: {
        items: 4,
        margin: 10,
      },
      1024: {
        items: 5,
        margin: 10,
      },
      1200: {
        items: 6,
        margin: 10,
      },
      1300: {
        items: 6.5,
        margin: 10,
      },
      1400: {
        items: 7,
        margin: 10,
      },
      1500: {
        items: 7,
        margin: 10,
      },
      1600: {
        items: 8,
        margin: 10,
      },
      1800: {
        items: 9,
        margin: 10,
      },
    },
  });

});


jQuery(function () {

  var $owl = jQuery(".service-slider");

  $owl.owlCarousel({
    items: 3,
    loop: false,
    margin: 40,
    nav: true,
    dots: false,
    smartSpeed: 1000,

    responsive: {
      0: { items: 1 },
      480: { items: 2, margin: 15 },
      576: {
        items: 2, margin: 20
      },
      768: { items: 3, margin: 15 },
      813: { items: 3, margin: 20 },
      961: { items: 3, margin: 20 },
      1200: { items: 3, margin: 25 },
      1500: { items: 3 }
    },

    onInitialized: checkNav,
    onResized: checkNav
  });

  function checkNav(event) {
    var totalItems = event.item.count;   // total items
    var visibleItems = event.page.size;  // visible items

    if (totalItems <= visibleItems) {
      $owl.find('.owl-nav').hide();   // hide arrows
    } else {
      $owl.find('.owl-nav').show();   // show arrows
    }
  }

});



jQuery(function () {

  jQuery(".testimonial-slider").owlCarousel({
    items: 3,
    loop: true,
    margin: 0,
    nav: false,
    dots: true,
    center: true,
    mouseDrag: true,
    touchDrag: true,
    pullDrag: true,

    autoplay: true,
    autoplayTimeout: 10000,
    autoplayHoverPause: true,
    smartSpeed: 1000,

    responsive: {
      0: {
        items: 1,
        autoHeight: true
      },

      576: {
        items: 1.5
      },

      767: {
        items: 2
      },

      961: {
        items: 3
      }
    }

  });

});


/* Mobile Bottom Bar — show after scroll, yellow at footer, hide at copyright */
jQuery(document).ready(function ($) {
  var $bar = $('.mobile-bottom-bar');
  var $footer = $('section.footer');
  var $copyright = $('.copyright-section');
  if ($bar.length && $copyright.length && $footer.length) {
    $(window).on('scroll', function () {
      var scrollTop = $(window).scrollTop();
      var windowHeight = $(window).height();
      var footerTop = $footer.offset().top;
      var copyrightTop = $copyright.offset().top;

      if (scrollTop > 100 && (scrollTop + windowHeight) < copyrightTop) {
        $bar.addClass('show');
        if ((scrollTop + windowHeight) >= footerTop) {
          $bar.addClass('footer-mode');
        } else {
          $bar.removeClass('footer-mode');
        }
      } else {
        $bar.removeClass('show');
        $bar.removeClass('footer-mode');
      }
    });
  }
});

